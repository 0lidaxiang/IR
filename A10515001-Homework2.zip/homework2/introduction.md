# Homework2 Introduction

# How to run
Use this command :
```
python3 main.py
```

## steps:
+ 1 : get the relevant documents

+ 2 : get the answer set of my IR system

+ 3 : get the relevant documents in the answer set

+ 4 : compute the precision of each relevant documents

+ 5 : compute the Average precision

+ 6 :  compute the mean Average precision
